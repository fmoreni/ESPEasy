module.exports = 'foo!';
